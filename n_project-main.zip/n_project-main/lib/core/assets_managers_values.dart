class AssetsManagersValue{
  static const String kLogo="assets/images/logo.png";
}